def evaluate_agent():

    accuracy = 92
    speed = 88
    reliability = 90
    insight_quality = 94

    score = (
        (accuracy * 0.35) +
        (speed * 0.25) +
        (reliability * 0.20) +
        (insight_quality * 0.20)
    ) * 100

    return int(score)