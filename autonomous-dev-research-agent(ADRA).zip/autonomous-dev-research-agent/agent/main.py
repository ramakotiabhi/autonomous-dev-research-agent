from planner import plan_task
from researcher import research_repo
from analyzer import analyze_repo
from evaluator import evaluate_agent

def run_agent(repo):

    plan = plan_task(repo)
    research = research_repo(repo)
    analysis = analyze_repo(repo)
    score = evaluate_agent()

    return {
        "plan": plan,
        "research": research,
        "analysis": analysis,
        "performance_score": score
    }

if __name__ == "__main__":

    repo = "../"

    result = run_agent(repo)

    print("----- AGENT OUTPUT -----")
    print(result)