import os

def analyze_repo(path):

    file_count = 0
    languages = {}

    for root, dirs, files in os.walk(path):

        for file in files:

            file_count += 1

            ext = file.split(".")[-1]

            languages[ext] = languages.get(ext, 0) + 1

    return {
        "files_scanned": file_count,
        "language_distribution": languages
    }