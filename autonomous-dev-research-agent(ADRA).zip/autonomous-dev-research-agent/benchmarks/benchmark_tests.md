# Benchmark Comparison

Agent vs Cursor Claude

Test Case 1:
Analyze Python Repository

Cursor Claude:
Provides high level explanation.

ADRA Agent:
- Files scanned
- Language distribution
- Repository insights
- Structured recommendations


Test Case 2:
Repository architecture explanation

Cursor Claude:
Generic explanation.

ADRA Agent:
Structured architecture insights and improvement suggestions.