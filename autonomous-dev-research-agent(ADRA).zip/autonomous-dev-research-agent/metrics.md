# Agent Performance Metrics

Score Range: 1 – 10,000

Score Formula:

Score =

(Accuracy × 0.35) +
(Speed × 0.25) +
(Reliability × 0.20) +
(Insight Quality × 0.20)

× 100


Example Evaluation

Accuracy = 92
Speed = 88
Reliability = 90
Insight Quality = 94


Calculation

Score =

(92 × 0.35) +
(88 × 0.25) +
(90 × 0.20) +
(94 × 0.20)

= 91

Final Score

9100 / 10000