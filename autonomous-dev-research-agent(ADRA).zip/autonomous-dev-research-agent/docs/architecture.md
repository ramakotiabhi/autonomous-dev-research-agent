# Architecture

ADRA Agent consists of 4 main components.

Planner
Determines tasks to perform on a repository.

Researcher
Provides high-level insights about repository structure.

Analyzer
Scans repository files and identifies language distribution.

Evaluator
Calculates performance score using defined metrics.

Workflow:

User → Agent Main
Main → Planner
Main → Researcher
Main → Analyzer
Main → Evaluator